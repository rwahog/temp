//package com.kitaphana.Testing;
//
//import java.sql.SQLException;
//
//public class launch {
//    public static void main(String[] args) throws SQLException {
//        TestDelivery3 test = new TestDelivery3();
//        test.test_case7();
//    }
//}
